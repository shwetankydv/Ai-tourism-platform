process.env.NODE_ENV = "test";
process.env.DATABASE_URL = process.env.DATABASE_URL ?? "postgresql://test:test@localhost:5432/travelai_test";
process.env.CLERK_SECRET_KEY = process.env.CLERK_SECRET_KEY ?? "test_clerk_secret";
process.env.CLERK_PUBLISHABLE_KEY = process.env.CLERK_PUBLISHABLE_KEY ?? "test_clerk_pub";
process.env.OPENAI_API_KEY = process.env.OPENAI_API_KEY ?? "test_openai_key";
