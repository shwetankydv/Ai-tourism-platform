import { createItinerarySchema } from "../src/types";

describe("createItinerarySchema", () => {
  it("accepts a valid payload", () => {
    const result = createItinerarySchema.safeParse({
      cityName: "Delhi",
      durationDays: 3,
      budgetTier: "MEDIUM",
      interests: ["history", "food"],
    });
    expect(result.success).toBe(true);
  });

  it("rejects durationDays above the max", () => {
    const result = createItinerarySchema.safeParse({
      cityName: "Delhi",
      durationDays: 30,
      budgetTier: "MEDIUM",
    });
    expect(result.success).toBe(false);
  });

  it("rejects an invalid budgetTier", () => {
    const result = createItinerarySchema.safeParse({
      cityName: "Delhi",
      durationDays: 3,
      budgetTier: "FREE",
    });
    expect(result.success).toBe(false);
  });

  it("defaults interests to an empty array", () => {
    const result = createItinerarySchema.parse({
      cityName: "Delhi",
      durationDays: 2,
      budgetTier: "LOW",
    });
    expect(result.interests).toEqual([]);
  });
});
