import { z } from "zod";

export const createItinerarySchema = z.object({
  cityName: z.string().min(1, "cityName is required"),
  durationDays: z.number().int().min(1).max(14),
  budgetTier: z.enum(["LOW", "MEDIUM", "HIGH", "LUXURY"]),
  interests: z.array(z.string()).default([]),
});

export type CreateItineraryInput = z.infer<typeof createItinerarySchema>;

export const createReviewSchema = z.object({
  targetType: z.enum(["attraction", "hotel", "restaurant", "itinerary"]),
  targetId: z.string().min(1),
  rating: z.number().int().min(1).max(5),
  comment: z.string().max(2000).optional(),
});

export type CreateReviewInput = z.infer<typeof createReviewSchema>;
