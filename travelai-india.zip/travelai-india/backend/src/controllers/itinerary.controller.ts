import { Response, NextFunction } from "express";
import crypto from "crypto";
import { prisma } from "../lib/prisma";
import { AuthedRequest } from "../middleware/auth";
import { ApiError } from "../middleware/errorHandler";
import { createItinerarySchema } from "../types";
import { generateItinerary } from "../services/ai.service";
import { getCityWeather } from "../services/weather.service";

export async function createItinerary(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).auth.userId as string;
    const input = createItinerarySchema.parse(req.body);

    const city = await prisma.city.findUnique({ where: { name: input.cityName } });
    if (!city) {
      throw new ApiError(404, `City "${input.cityName}" is not supported yet.`);
    }

    const [attractions, hotels, restaurants, weather] = await Promise.all([
      prisma.attraction.findMany({ where: { cityId: city.id } }),
      prisma.hotel.findMany({ where: { cityId: city.id } }),
      prisma.restaurant.findMany({ where: { cityId: city.id } }),
      getCityWeather(city.name),
    ]);

    if (attractions.length === 0) {
      throw new ApiError(422, `No curated data available for ${city.name} yet.`);
    }

    const plan = await generateItinerary({
      city,
      durationDays: input.durationDays,
      budgetTier: input.budgetTier,
      interests: input.interests,
      attractions,
      hotels,
      restaurants,
      weather,
    });

    const itinerary = await prisma.itinerary.create({
      data: {
        userId,
        cityId: city.id,
        title: plan.title,
        durationDays: input.durationDays,
        budgetTier: input.budgetTier,
        interests: input.interests,
        estimatedCostInr: plan.estimatedCostInr,
        aiRawPlan: plan as any,
        days: {
          create: plan.days.map((day) => ({
            dayNumber: day.dayNumber,
            summary: day.summary,
            weatherNote: day.weatherNote,
            items: {
              create: day.items.map((item) => ({
                order: item.order,
                startTime: item.startTime,
                title: item.title,
                type: item.type,
                description: item.description,
                estimatedCostInr: item.estimatedCostInr,
                latitude: item.latitude,
                longitude: item.longitude,
              })),
            },
          })),
        },
      },
      include: { days: { include: { items: true } }, city: true },
    });

    res.status(201).json({ itinerary, safetyTips: plan.safetyTips, localRecommendations: plan.localRecommendations, weather });
  } catch (err) {
    next(err);
  }
}

export async function listMyItineraries(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).auth.userId as string;
    const itineraries = await prisma.itinerary.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      include: { city: true, days: { select: { id: true, dayNumber: true } } },
    });
    res.json({ itineraries });
  } catch (err) {
    next(err);
  }
}

export async function getItinerary(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).auth.userId as string;
    const { id } = req.params;

    const itinerary = await prisma.itinerary.findUnique({
      where: { id },
      include: { days: { include: { items: { orderBy: { order: "asc" } } }, orderBy: { dayNumber: "asc" } }, city: true },
    });

    if (!itinerary) throw new ApiError(404, "Itinerary not found.");
    if (itinerary.userId !== userId && itinerary.visibility === "PRIVATE") {
      throw new ApiError(403, "You do not have access to this itinerary.");
    }

    res.json({ itinerary });
  } catch (err) {
    next(err);
  }
}

export async function shareItinerary(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).auth.userId as string;
    const { id } = req.params;

    const itinerary = await prisma.itinerary.findUnique({ where: { id } });
    if (!itinerary) throw new ApiError(404, "Itinerary not found.");
    if (itinerary.userId !== userId) throw new ApiError(403, "Only the owner can share this itinerary.");

    const shareToken = itinerary.shareToken ?? crypto.randomBytes(12).toString("hex");

    const updated = await prisma.itinerary.update({
      where: { id },
      data: { visibility: "SHARED", shareToken },
    });

    res.json({ shareUrl: `${process.env.FRONTEND_URL}/itinerary/shared/${updated.shareToken}` });
  } catch (err) {
    next(err);
  }
}

export async function getSharedItinerary(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const { token } = req.params;
    const itinerary = await prisma.itinerary.findUnique({
      where: { shareToken: token },
      include: { days: { include: { items: { orderBy: { order: "asc" } } }, orderBy: { dayNumber: "asc" } }, city: true },
    });

    if (!itinerary || itinerary.visibility === "PRIVATE") {
      throw new ApiError(404, "Shared itinerary not found.");
    }

    res.json({ itinerary });
  } catch (err) {
    next(err);
  }
}
