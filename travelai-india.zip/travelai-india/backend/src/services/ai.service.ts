import OpenAI from "openai";
import { env } from "../lib/env";
import { City, Attraction, Hotel, Restaurant, BudgetTier } from "@prisma/client";
import { WeatherSummary } from "./weather.service";
import { ApiError } from "../middleware/errorHandler";

const openai = new OpenAI({ apiKey: env.OPENAI_API_KEY });

export interface ItineraryItemPlan {
  order: number;
  startTime: string;
  title: string;
  type: "attraction" | "hotel" | "restaurant" | "transport" | "tip";
  description: string;
  estimatedCostInr: number;
  latitude?: number;
  longitude?: number;
}

export interface ItineraryDayPlan {
  dayNumber: number;
  summary: string;
  weatherNote?: string;
  items: ItineraryItemPlan[];
}

export interface ItineraryPlan {
  title: string;
  estimatedCostInr: number;
  safetyTips: string[];
  localRecommendations: string[];
  days: ItineraryDayPlan[];
}

interface GenerateItineraryInput {
  city: City;
  durationDays: number;
  budgetTier: BudgetTier;
  interests: string[];
  attractions: Attraction[];
  hotels: Hotel[];
  restaurants: Restaurant[];
  weather: WeatherSummary | null;
}

const RESPONSE_SCHEMA_HINT = `
Respond with ONLY valid JSON (no markdown fences, no commentary) matching exactly this shape:
{
  "title": string,
  "estimatedCostInr": number,
  "safetyTips": string[],
  "localRecommendations": string[],
  "days": [
    {
      "dayNumber": number,
      "summary": string,
      "weatherNote": string,
      "items": [
        {
          "order": number,
          "startTime": "HH:MM",
          "title": string,
          "type": "attraction" | "hotel" | "restaurant" | "transport" | "tip",
          "description": string,
          "estimatedCostInr": number,
          "latitude": number,
          "longitude": number
        }
      ]
    }
  ]
}
`;

export async function generateItinerary(input: GenerateItineraryInput): Promise<ItineraryPlan> {
  const { city, durationDays, budgetTier, interests, attractions, hotels, restaurants, weather } = input;

  // Ground the model in real, curated local data so it doesn't hallucinate
  // addresses/prices. The model's job is to sequence and personalize, not invent facts.
  const context = {
    city: { name: city.name, state: city.state, description: city.description },
    attractions: attractions.map((a) => ({ name: a.name, category: a.category, avgCostInr: a.avgCostInr, lat: a.latitude, lng: a.longitude, rating: a.rating })),
    hotels: hotels.filter((h) => h.budgetTier === budgetTier).map((h) => ({ name: h.name, pricePerNightInr: h.pricePerNightInr, lat: h.latitude, lng: h.longitude, rating: h.rating })),
    restaurants: restaurants.map((r) => ({ name: r.name, cuisine: r.cuisine, avgCostInr: r.avgCostInr, lat: r.latitude, lng: r.longitude, rating: r.rating })),
    weather,
  };

  const systemPrompt = `You are an expert India travel planner creating itineraries for tourists visiting ${city.name}.
Rules:
- ONLY use attractions, hotels, and restaurants from the provided context data. Do not invent new venues.
- Build a realistic day-by-day plan for ${durationDays} day(s), budget tier "${budgetTier}", interests: ${interests.join(", ") || "general sightseeing"}.
- Include transportation suggestions between stops (auto-rickshaw, metro, cab) with realistic Delhi costs in INR.
- Include at least one restaurant per day and hotel recommendation appears once (on day 1) unless the trip is a day trip.
- Include 3-6 safety tips relevant to ${city.name} and India travel generally (traffic, scams, water, dress code as applicable).
- Include 3-5 local recommendations (etiquette, best time to visit spots, bargaining tips, local food to try).
- Sum item costs realistically into estimatedCostInr for the whole trip.
- Weather note per day should reflect the provided current weather context if present.
${RESPONSE_SCHEMA_HINT}`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    temperature: 0.6,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Context data:\n${JSON.stringify(context)}` },
    ],
  });

  const raw = completion.choices[0]?.message?.content;
  if (!raw) {
    throw new ApiError(502, "AI service returned an empty response.");
  }

  try {
    const parsed = JSON.parse(raw) as ItineraryPlan;
    if (!parsed.days || !Array.isArray(parsed.days)) {
      throw new Error("Missing days array");
    }
    return parsed;
  } catch (err) {
    console.error("Failed to parse AI response:", raw);
    throw new ApiError(502, "AI service returned malformed itinerary data.");
  }
}
