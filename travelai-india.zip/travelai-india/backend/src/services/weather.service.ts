import { env } from "../lib/env";

export interface WeatherSummary {
  tempC: number;
  feelsLikeC: number;
  condition: string;
  humidity: number;
  advisory: string;
}

// Returns current weather for a city, or null if the weather API is not
// configured / fails — callers must treat weather as optional enrichment,
// never a hard dependency for itinerary generation.
export async function getCityWeather(cityName: string): Promise<WeatherSummary | null> {
  if (!env.OPENWEATHER_API_KEY) return null;

  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
      cityName
    )},IN&units=metric&appid=${env.OPENWEATHER_API_KEY}`;
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();

    const tempC = data.main?.temp ?? null;
    const condition = data.weather?.[0]?.main ?? "Unknown";
    if (tempC === null) return null;

    let advisory = "Weather looks moderate — standard precautions apply.";
    if (tempC >= 38) advisory = "Extreme heat expected. Stay hydrated, avoid midday outdoor activity, wear light clothing.";
    else if (tempC <= 10) advisory = "Cold conditions. Carry warm layers, especially for early morning/evening plans.";
    else if (/rain|thunderstorm/i.test(condition)) advisory = "Rain likely. Carry an umbrella and plan indoor backup activities.";

    return {
      tempC,
      feelsLikeC: data.main?.feels_like ?? tempC,
      condition,
      humidity: data.main?.humidity ?? 0,
      advisory,
    };
  } catch (err) {
    console.error("Weather fetch failed:", err);
    return null;
  }
}
