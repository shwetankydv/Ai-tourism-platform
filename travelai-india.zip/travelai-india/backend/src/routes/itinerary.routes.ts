import { Router } from "express";
import { requireAuth, syncUser } from "../middleware/auth";
import {
  createItinerary,
  listMyItineraries,
  getItinerary,
  shareItinerary,
  getSharedItinerary,
} from "../controllers/itinerary.controller";

const router = Router();

// Public: view a shared itinerary via its token, no auth required.
router.get("/shared/:token", getSharedItinerary);

// Protected routes below.
router.use(requireAuth, syncUser);

router.post("/", createItinerary);
router.get("/", listMyItineraries);
router.get("/:id", getItinerary);
router.post("/:id/share", shareItinerary);

export default router;
