import { Router } from "express";
import { requireAuth, syncUser, AuthedRequest } from "../middleware/auth";
import { prisma } from "../lib/prisma";
import { createReviewSchema } from "../types";

const router = Router();

router.get("/:targetType/:targetId", async (req, res, next) => {
  try {
    const { targetType, targetId } = req.params;
    const reviews = await prisma.review.findMany({
      where: { targetType, targetId },
      orderBy: { createdAt: "desc" },
      include: { user: { select: { name: true, avatarUrl: true } } },
    });
    res.json({ reviews });
  } catch (err) {
    next(err);
  }
});

router.post("/", requireAuth, syncUser, async (req: AuthedRequest, res, next) => {
  try {
    const userId = (req as any).auth.userId as string;
    const input = createReviewSchema.parse(req.body);
    const review = await prisma.review.create({ data: { ...input, userId } });
    res.status(201).json({ review });
  } catch (err) {
    next(err);
  }
});

export default router;
