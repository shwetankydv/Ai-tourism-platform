import { Router } from "express";
import OpenAI from "openai";
import { z } from "zod";
import { env } from "../lib/env";
import { requireAuth } from "../middleware/auth";

const router = Router();
const openai = new OpenAI({ apiKey: env.OPENAI_API_KEY });

const chatSchema = z.object({
  message: z.string().min(1).max(1000),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string() }))
    .max(20)
    .default([]),
  cityContext: z.string().optional(),
});

router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { message, history, cityContext } = chatSchema.parse(req.body);

    const systemPrompt = `You are the TravelAI India assistant, a helpful, safety-conscious guide for tourists in India${
      cityContext ? ` currently focused on ${cityContext}` : ""
    }. Give concise, practical answers about transport, costs in INR, safety, culture, and logistics. If asked about something outside travel in India, politely redirect to travel topics.`;

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      temperature: 0.5,
      messages: [
        { role: "system", content: systemPrompt },
        ...history.map((h) => ({ role: h.role, content: h.content } as const)),
        { role: "user", content: message },
      ],
    });

    const reply = completion.choices[0]?.message?.content ?? "Sorry, I couldn't generate a response.";
    res.json({ reply });
  } catch (err) {
    next(err);
  }
});

export default router;
