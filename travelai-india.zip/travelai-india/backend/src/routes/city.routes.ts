import { Router } from "express";
import { prisma } from "../lib/prisma";

const router = Router();

router.get("/", async (_req, res, next) => {
  try {
    const cities = await prisma.city.findMany({ select: { id: true, name: true, state: true, description: true } });
    res.json({ cities });
  } catch (err) {
    next(err);
  }
});

router.get("/:name/emergency-contacts", async (req, res, next) => {
  try {
    const city = await prisma.city.findUnique({ where: { name: req.params.name } });
    if (!city) return res.status(404).json({ error: "City not found." });
    const contacts = await prisma.emergencyContact.findMany({ where: { cityId: city.id } });
    res.json({ contacts });
  } catch (err) {
    next(err);
  }
});

export default router;
