import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import { env } from "./lib/env";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import itineraryRoutes from "./routes/itinerary.routes";
import cityRoutes from "./routes/city.routes";
import reviewRoutes from "./routes/review.routes";
import chatRoutes from "./routes/chat.routes";

const app = express();

app.use(helmet());
app.use(cors({ origin: env.FRONTEND_URL, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan(env.NODE_ENV === "production" ? "combined" : "dev"));

// Global rate limit: protects the AI endpoints (which cost real money per call)
// from abuse. Tighter limits can be layered per-route if needed.
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

app.get("/health", (_req, res) => res.json({ status: "ok", timestamp: new Date().toISOString() }));

app.use("/api/itineraries", itineraryRoutes);
app.use("/api/cities", cityRoutes);
app.use("/api/reviews", reviewRoutes);
app.use("/api/chat", chatRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const port = Number(env.PORT);
app.listen(port, () => {
  console.log(`TravelAI India backend listening on port ${port} [${env.NODE_ENV}]`);
});

export default app;
