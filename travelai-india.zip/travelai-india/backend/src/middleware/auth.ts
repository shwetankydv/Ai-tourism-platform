import { Request, Response, NextFunction } from "express";
import { ClerkExpressRequireAuth, ClerkExpressWithAuth } from "@clerk/clerk-sdk-node";
import { prisma } from "../lib/prisma";

export interface AuthedRequest extends Request {
  auth?: { userId: string };
}

// Requires a valid Clerk session; rejects with 401 otherwise.
export const requireAuth = ClerkExpressRequireAuth({
  onError: (_req, res: Response) => {
    res.status(401).json({ error: "Unauthorized. Please sign in." });
  },
});

// Attaches auth if present, but does not block unauthenticated requests.
export const withAuth = ClerkExpressWithAuth();

// Ensures a corresponding User row exists in our DB the first time an
// authenticated Clerk user hits a protected route (JIT provisioning).
export async function syncUser(req: AuthedRequest, res: Response, next: NextFunction) {
  try {
    const auth = (req as any).auth;
    if (!auth?.userId) {
      return res.status(401).json({ error: "Unauthorized." });
    }

    const existing = await prisma.user.findUnique({ where: { id: auth.userId } });
    if (!existing) {
      const claims = auth.sessionClaims as { email?: string; name?: string; picture?: string } | undefined;
      await prisma.user.create({
        data: {
          id: auth.userId,
          email: claims?.email ?? `${auth.userId}@unknown.travelai`,
          name: claims?.name,
          avatarUrl: claims?.picture,
        },
      });
    }

    next();
  } catch (err) {
    next(err);
  }
}
