import { PrismaClient, BudgetTier } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const delhi = await prisma.city.upsert({
    where: { name: "Delhi" },
    update: {},
    create: {
      name: "Delhi",
      state: "Delhi",
      latitude: 28.6139,
      longitude: 77.209,
      description: "India's capital, blending Mughal history with a modern metropolis.",
    },
  });

  await prisma.attraction.createMany({
    data: [
      {
        cityId: delhi.id,
        name: "Red Fort",
        category: "Historical",
        description: "17th-century Mughal fortress and UNESCO World Heritage Site.",
        latitude: 28.6562,
        longitude: 77.241,
        avgCostInr: 50,
        rating: 4.5,
      },
      {
        cityId: delhi.id,
        name: "Qutub Minar",
        category: "Historical",
        description: "12th-century minaret, tallest brick minaret in the world.",
        latitude: 28.5245,
        longitude: 77.1855,
        avgCostInr: 40,
        rating: 4.6,
      },
      {
        cityId: delhi.id,
        name: "India Gate",
        category: "Landmark",
        description: "War memorial and popular evening gathering spot.",
        latitude: 28.6129,
        longitude: 77.2295,
        avgCostInr: 0,
        rating: 4.6,
      },
      {
        cityId: delhi.id,
        name: "Lotus Temple",
        category: "Religious",
        description: "Bahá'í House of Worship known for its flower-like shape.",
        latitude: 28.5535,
        longitude: 77.2588,
        avgCostInr: 0,
        rating: 4.7,
      },
    ],
    skipDuplicates: true,
  });

  await prisma.hotel.createMany({
    data: [
      {
        cityId: delhi.id,
        name: "Zostel Delhi",
        budgetTier: BudgetTier.LOW,
        pricePerNightInr: 700,
        latitude: 28.6448,
        longitude: 77.2167,
        rating: 4.2,
      },
      {
        cityId: delhi.id,
        name: "Bloomrooms @ New Delhi Railway Station",
        budgetTier: BudgetTier.MEDIUM,
        pricePerNightInr: 3200,
        latitude: 28.6431,
        longitude: 77.2197,
        rating: 4.1,
      },
      {
        cityId: delhi.id,
        name: "The Leela Palace New Delhi",
        budgetTier: BudgetTier.LUXURY,
        pricePerNightInr: 22000,
        latitude: 28.5921,
        longitude: 77.2216,
        rating: 4.8,
      },
    ],
    skipDuplicates: true,
  });

  await prisma.restaurant.createMany({
    data: [
      {
        cityId: delhi.id,
        name: "Karim's (Jama Masjid)",
        cuisine: "Mughlai",
        avgCostInr: 400,
        latitude: 28.6507,
        longitude: 77.2334,
        rating: 4.4,
      },
      {
        cityId: delhi.id,
        name: "Indian Accent",
        cuisine: "Modern Indian",
        avgCostInr: 4500,
        latitude: 28.5988,
        longitude: 77.1855,
        rating: 4.7,
      },
    ],
    skipDuplicates: true,
  });

  await prisma.emergencyContact.createMany({
    data: [
      { cityId: delhi.id, label: "Police", phone: "100" },
      { cityId: delhi.id, label: "Ambulance", phone: "102" },
      { cityId: delhi.id, label: "Tourist Helpline (24x7)", phone: "1363" },
      { cityId: delhi.id, label: "Women Helpline", phone: "1091" },
    ],
    skipDuplicates: true,
  });

  console.log("Seed complete: Delhi city + attractions + hotels + restaurants + emergency contacts");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
