# TravelAI India

AI-powered trip planning for Indian cities, starting with Delhi. Users pick a city, budget,
duration, and interests; the backend grounds an OpenAI model in curated local data (attractions,
hotels, restaurants, live weather) to produce a structured, costed, day-by-day itinerary.

This repo is an **MVP core**: full auth, database, and one complete end-to-end feature
(AI itinerary generation, viewing, sharing) built to production standards. It's the foundation
to extend with the remaining roadmap features below.

## What's implemented

- Email + Google sign-in via Clerk (frontend + backend JWT verification)
- PostgreSQL schema (Prisma) covering users, cities, itineraries, attractions, hotels,
  restaurants, reviews, emergency contacts
- AI itinerary generator (OpenAI, grounded in seeded Delhi data, JSON-schema constrained)
- Live weather enrichment (OpenWeather, degrades gracefully if unset)
- Save/view/share itineraries (shareable public link)
- Reviews API (ratings + comments on any entity type)
- AI chatbot endpoint for travel Q&A
- Dockerized backend + frontend + Postgres, one-command local dev
- CI (GitHub Actions): lint, test, build on every PR
- Backend unit/integration tests (Jest + Supertest)

## What's stubbed / roadmap (not yet built)

Interactive Google Maps rendering, hotel/restaurant browse-and-filter UI, budget planner
visualizations, admin dashboard, and multi-city expansion beyond Delhi. The database schema
and APIs are already shaped to support all of these — ask to build out any of them next.

## Tech stack

| Layer | Choice |
|---|---|
| Frontend | Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS |
| Backend | Node.js, Express, TypeScript |
| Database | PostgreSQL + Prisma ORM |
| Auth | Clerk (Email + Google OAuth) |
| AI | OpenAI (`gpt-4o-mini`, JSON mode) |
| Weather | OpenWeather API |
| Maps | Google Maps JS API (client key wired, map component not yet built) |
| Deployment | Vercel (frontend) + Railway (backend + Postgres) |

## Project structure

```
travelai-india/
├── backend/
│   ├── src/
│   │   ├── controllers/       # request handlers
│   │   ├── routes/            # express routers
│   │   ├── services/          # AI + weather integrations
│   │   ├── middleware/        # auth, error handling
│   │   ├── lib/                # prisma client, env validation
│   │   ├── types/             # zod schemas
│   │   └── index.ts           # app entrypoint
│   ├── prisma/
│   │   ├── schema.prisma
│   │   └── seed.ts
│   ├── tests/
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── app/                # routes (App Router)
│   │   ├── components/
│   │   ├── lib/                # API client
│   │   └── types/
│   ├── Dockerfile
│   └── .env.example
├── .github/workflows/ci.yml
├── docker-compose.yml
└── README.md
```

## Local setup

### Prerequisites
- Node.js 20+
- Docker (for Postgres, or run Postgres locally yourself)
- API keys: Clerk, OpenAI, (optional) OpenWeather, (optional) Google Maps

### 1. Clone and configure environment

```bash
git clone <your-repo-url> travelai-india
cd travelai-india
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
# Fill in CLERK_*, OPENAI_API_KEY, etc. in both files
```

### 2. Start Postgres

```bash
docker compose up -d postgres
```

### 3. Backend

```bash
cd backend
npm install
npx prisma migrate dev --name init
npm run prisma:seed
npm run dev        # http://localhost:4000
```

### 4. Frontend

```bash
cd frontend
npm install
npm run dev         # http://localhost:3000
```

### 5. Run tests

```bash
cd backend
npm test
```

## Full stack via Docker

```bash
docker compose up --build
```

Runs Postgres, backend (`:4000`), and frontend (`:3000`) together. Set the required env vars
in a `.env` file at the repo root (Clerk keys, OpenAI key) before running — `docker-compose.yml`
reads them via `${VARIABLE}` interpolation.

## API overview

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/health` | none | Liveness check |
| GET | `/api/cities` | none | List supported cities |
| GET | `/api/cities/:name/emergency-contacts` | none | Emergency numbers for a city |
| POST | `/api/itineraries` | required | Generate a new AI itinerary |
| GET | `/api/itineraries` | required | List the current user's saved trips |
| GET | `/api/itineraries/:id` | required | Get one itinerary |
| POST | `/api/itineraries/:id/share` | required | Generate a public share link |
| GET | `/api/itineraries/shared/:token` | none | View a shared itinerary |
| GET | `/api/reviews/:targetType/:targetId` | none | List reviews for an entity |
| POST | `/api/reviews` | required | Submit a review |
| POST | `/api/chat` | required | AI travel-assistant chat turn |

All protected routes expect `Authorization: Bearer <Clerk session JWT>`.

### Example: generate an itinerary

```bash
curl -X POST http://localhost:4000/api/itineraries \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "cityName": "Delhi",
    "durationDays": 3,
    "budgetTier": "MEDIUM",
    "interests": ["History", "Food"]
  }'
```

## Deployment

**Backend → Railway**
1. New Railway project → add a PostgreSQL plugin (gives you `DATABASE_URL`)
2. Deploy `backend/` as a service (Railway auto-detects the Dockerfile)
3. Set env vars from `backend/.env.example` in the Railway dashboard
4. Run `npx prisma migrate deploy` (via Railway's shell or a release command)

**Frontend → Vercel**
1. Import the repo, set root directory to `frontend/`
2. Set env vars from `frontend/.env.example`
3. Set `NEXT_PUBLIC_API_URL` to your deployed Railway backend URL

## Security notes

- All secrets loaded via env vars, validated at boot with Zod (`src/lib/env.ts`) — the app
  fails fast instead of misbehaving with missing config.
- Helmet + CORS locked to `FRONTEND_URL` + rate limiting on the Express app.
- Clerk verifies JWTs server-side on every protected route; no session state is trusted from
  the client.
- AI prompts are grounded in curated DB data to prevent cost/venue hallucination.

## License

MIT — adapt freely.
