import Link from "next/link";

export default function HomePage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-16">
      <section className="text-center">
        <h1 className="text-4xl font-bold tracking-tight text-navy sm:text-5xl">
          Explore India, <span className="text-saffron">Planned by AI</span>
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
          Tell us your city, budget, and interests. Get a personalized day-by-day itinerary with
          routes, hotels, restaurants, costs, and safety tips — starting with Delhi.
        </p>
        <div className="mt-8">
          <Link
            href="/itinerary"
            className="inline-block rounded-md bg-indiaGreen px-6 py-3 text-base font-semibold text-white hover:bg-indiaGreen/90"
          >
            Plan My Trip
          </Link>
        </div>
      </section>

      <section className="mt-20 grid grid-cols-1 gap-6 sm:grid-cols-3">
        {[
          { title: "AI Itinerary Generator", desc: "A full day-by-day plan built around your budget and interests." },
          { title: "Real Costs, Real Places", desc: "Curated attractions, hotels, and restaurants with INR pricing." },
          { title: "Safety & Weather Aware", desc: "Live weather context and local safety tips baked into every plan." },
        ].map((f) => (
          <div key={f.title} className="rounded-lg border border-slate-200 bg-white p-6">
            <h3 className="font-semibold text-navy">{f.title}</h3>
            <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
