import type { Metadata } from "next";
import { ClerkProvider, SignedIn, SignedOut, SignInButton, UserButton } from "@clerk/nextjs";
import "./globals.css";

export const metadata: Metadata = {
  title: "TravelAI India — AI-Powered Trip Planning",
  description: "Personalized AI itineraries for exploring Indian cities.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>
          <header className="border-b border-slate-200 bg-white">
            <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
              <a href="/" className="text-lg font-bold text-navy">
                Travel<span className="text-saffron">AI</span> India
              </a>
              <nav className="flex items-center gap-4">
                <SignedIn>
                  <a href="/itinerary" className="text-sm font-medium text-slate-700 hover:text-navy">
                    Plan a Trip
                  </a>
                  <a href="/trips" className="text-sm font-medium text-slate-700 hover:text-navy">
                    My Trips
                  </a>
                  <UserButton afterSignOutUrl="/" />
                </SignedIn>
                <SignedOut>
                  <SignInButton mode="modal">
                    <button className="rounded-md bg-navy px-4 py-2 text-sm font-medium text-white hover:bg-navy/90">
                      Sign In
                    </button>
                  </SignInButton>
                </SignedOut>
              </nav>
            </div>
          </header>
          <main>{children}</main>
        </body>
      </html>
    </ClerkProvider>
  );
}
