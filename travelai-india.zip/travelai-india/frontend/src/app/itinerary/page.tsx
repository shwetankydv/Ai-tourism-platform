"use client";

import { useState } from "react";
import { useAuth } from "@clerk/nextjs";
import { apiFetch, ApiClientError } from "@/lib/api";
import { CreateItineraryResponse, BudgetTier } from "@/types/itinerary";
import ItineraryResult from "@/components/ItineraryResult";

const INTEREST_OPTIONS = ["History", "Food", "Shopping", "Nature", "Nightlife", "Spirituality", "Art & Museums"];

export default function ItineraryPlannerPage() {
  const { getToken } = useAuth();
  const [cityName, setCityName] = useState("Delhi");
  const [durationDays, setDurationDays] = useState(3);
  const [budgetTier, setBudgetTier] = useState<BudgetTier>("MEDIUM");
  const [interests, setInterests] = useState<string[]>(["History", "Food"]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CreateItineraryResponse | null>(null);

  function toggleInterest(interest: string) {
    setInterests((prev) => (prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await apiFetch<CreateItineraryResponse>("/api/itineraries", {
        method: "POST",
        body: JSON.stringify({ cityName, durationDays, budgetTier, interests }),
        getToken,
      });
      setResult(data);
    } catch (err) {
      setError(err instanceof ApiClientError ? err.message : "Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-3xl font-bold text-navy">Plan Your Trip</h1>
      <p className="mt-1 text-slate-600">Tell us what you're looking for and let AI build your itinerary.</p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-6 rounded-lg border border-slate-200 bg-white p-6">
        <div>
          <label className="block text-sm font-medium text-slate-700">City</label>
          <select
            value={cityName}
            onChange={(e) => setCityName(e.target.value)}
            className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
          >
            <option value="Delhi">Delhi</option>
          </select>
          <p className="mt-1 text-xs text-slate-500">More cities coming soon.</p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700">Duration (days)</label>
            <input
              type="number"
              min={1}
              max={14}
              value={durationDays}
              onChange={(e) => setDurationDays(Number(e.target.value))}
              className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700">Budget</label>
            <select
              value={budgetTier}
              onChange={(e) => setBudgetTier(e.target.value as BudgetTier)}
              className="mt-1 w-full rounded-md border border-slate-300 px-3 py-2"
            >
              <option value="LOW">Low (backpacker)</option>
              <option value="MEDIUM">Medium (comfort)</option>
              <option value="HIGH">High (premium)</option>
              <option value="LUXURY">Luxury</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700">Interests</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {INTEREST_OPTIONS.map((interest) => (
              <button
                type="button"
                key={interest}
                onClick={() => toggleInterest(interest)}
                className={`rounded-full border px-3 py-1 text-sm ${
                  interests.includes(interest)
                    ? "border-indiaGreen bg-indiaGreen/10 text-indiaGreen"
                    : "border-slate-300 text-slate-600"
                }`}
              >
                {interest}
              </button>
            ))}
          </div>
        </div>

        {error && <p className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-md bg-navy px-4 py-3 font-semibold text-white hover:bg-navy/90 disabled:opacity-50"
        >
          {loading ? "Generating your itinerary…" : "Generate Itinerary"}
        </button>
      </form>

      {result && <ItineraryResult data={result} />}
    </div>
  );
}
