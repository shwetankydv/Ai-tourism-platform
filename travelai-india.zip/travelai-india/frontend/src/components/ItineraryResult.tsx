import { CreateItineraryResponse } from "@/types/itinerary";

export default function ItineraryResult({ data }: { data: CreateItineraryResponse }) {
  const { itinerary, safetyTips, localRecommendations, weather } = data;

  return (
    <div className="mt-8 space-y-8">
      <div className="rounded-lg border border-slate-200 bg-white p-6">
        <h2 className="text-2xl font-bold text-navy">{itinerary.title}</h2>
        <p className="mt-1 text-sm text-slate-600">
          {itinerary.city.name}, {itinerary.city.state} · {itinerary.durationDays} day(s) · {itinerary.budgetTier} budget
        </p>
        <p className="mt-2 text-lg font-semibold text-indiaGreen">
          Estimated cost: ₹{itinerary.estimatedCostInr.toLocaleString("en-IN")}
        </p>
        {weather && (
          <p className="mt-2 text-sm text-slate-600">
            Current weather: {weather.tempC}°C, {weather.condition}. {weather.advisory}
          </p>
        )}
      </div>

      {itinerary.days.map((day) => (
        <div key={day.id} className="rounded-lg border border-slate-200 bg-white p-6">
          <h3 className="text-lg font-semibold text-navy">
            Day {day.dayNumber}: {day.summary}
          </h3>
          {day.weatherNote && <p className="mt-1 text-xs text-slate-500">{day.weatherNote}</p>}
          <ul className="mt-4 space-y-3">
            {day.items.map((item) => (
              <li key={item.id} className="flex gap-4 border-l-2 border-saffron pl-4">
                <span className="w-16 shrink-0 text-sm font-medium text-slate-500">{item.startTime}</span>
                <div>
                  <p className="font-medium text-slate-900">
                    {item.title}{" "}
                    <span className="ml-2 rounded bg-slate-100 px-2 py-0.5 text-xs uppercase text-slate-500">
                      {item.type}
                    </span>
                  </p>
                  <p className="text-sm text-slate-600">{item.description}</p>
                  {item.estimatedCostInr > 0 && (
                    <p className="text-xs text-slate-500">₹{item.estimatedCostInr.toLocaleString("en-IN")}</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
      ))}

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h4 className="font-semibold text-navy">Safety Tips</h4>
          <ul className="mt-2 list-inside list-disc space-y-1 text-sm text-slate-600">
            {safetyTips.map((tip, i) => (
              <li key={i}>{tip}</li>
            ))}
          </ul>
        </div>
        <div className="rounded-lg border border-slate-200 bg-white p-6">
          <h4 className="font-semibold text-navy">Local Recommendations</h4>
          <ul className="mt-2 list-inside list-disc space-y-1 text-sm text-slate-600">
            {localRecommendations.map((rec, i) => (
              <li key={i}>{rec}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
