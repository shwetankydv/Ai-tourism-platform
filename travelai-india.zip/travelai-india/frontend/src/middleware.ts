import { authMiddleware } from "@clerk/nextjs";

// Public routes: landing page, sign-in/up flows, and shared itinerary links
// (so someone without an account can view a trip that was shared with them).
export default authMiddleware({
  publicRoutes: ["/", "/sign-in(.*)", "/sign-up(.*)", "/itinerary/shared/(.*)"],
});

export const config = {
  matcher: ["/((?!.*\\..*|_next).*)", "/", "/(api|trpc)(.*)"],
};
