export type BudgetTier = "LOW" | "MEDIUM" | "HIGH" | "LUXURY";

export interface ItineraryItem {
  id: string;
  order: number;
  startTime: string;
  title: string;
  type: "attraction" | "hotel" | "restaurant" | "transport" | "tip";
  description: string;
  estimatedCostInr: number;
  latitude?: number | null;
  longitude?: number | null;
}

export interface ItineraryDay {
  id: string;
  dayNumber: number;
  summary: string;
  weatherNote?: string | null;
  items: ItineraryItem[];
}

export interface Itinerary {
  id: string;
  title: string;
  durationDays: number;
  budgetTier: BudgetTier;
  interests: string[];
  estimatedCostInr: number;
  city: { name: string; state: string };
  days: ItineraryDay[];
}

export interface CreateItineraryResponse {
  itinerary: Itinerary;
  safetyTips: string[];
  localRecommendations: string[];
  weather: { tempC: number; condition: string; advisory: string } | null;
}
